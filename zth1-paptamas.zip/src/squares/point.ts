export interface Point {
  x: string;
  y: string;
}
