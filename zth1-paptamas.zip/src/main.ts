import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";
import * as PostgressConnectionStringParser from "pg-connection-string";
import { Logger } from "@nestjs/common";
import { ConnectionOptions, createConnection } from "typeorm";

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  /*const databaseUrl: string = process.env.DATABASE_URL;
  const connectionOptions = PostgressConnectionStringParser.parse(databaseUrl);
  Logger.log(connectionOptions);
  const typeOrmOptions: ConnectionOptions = {
    type: "postgres",
    host: connectionOptions.host,
    port: parseInt(connectionOptions.port),
    username: connectionOptions.user,
    password: connectionOptions.password,
    database: connectionOptions.database,
    logging: true,
    synchronize: true,
  };
  const connection = createConnection(typeOrmOptions);
  Logger.log((await connection).query("SELECT * FROM demmo7ppms9t5j"));
  Logger.log(connection);*/
  await app.listen(process.env.PORT || 3000);
}
bootstrap();
